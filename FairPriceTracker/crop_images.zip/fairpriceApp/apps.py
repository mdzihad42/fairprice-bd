from django.apps import AppConfig


class FairpriceappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fairpriceApp'
